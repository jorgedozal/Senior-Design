import tkinter
from tkinter import *
from tkinter import ttk
from tkinter.font import Font
from PIL import Image, ImageTk

root = Tk()
root.geometry('1920x1280')
my_font = Font(family="Times New Roman", size=16, weight="bold", slant="italic", underline=1)

ttk.Label(root, text=' ', background='black').place(x=0, y=0, width=1920, height=1280)
ttk.Label(root, text='map', background='green').place(x=15, y=290, width=1890, height=975)


#WeatherBlock1
ttk.Label(root, text=' ', background='white').place(x=15, y=15, width=200, height=265) # creating white box
#WeatherBlock2
ttk.Label(root, text=' ', background='white').place(x=225, y=15, width=200, height=265)
#WeatherBlock3
ttk.Label(root, text=' ', background='white').place(x=435, y=15, width=200, height=265)


wind = Image.open("wind.jpg") # Create a photoimage object of the image in the path
windi = ImageTk.PhotoImage(wind)
wind1 = tkinter.Label(image=windi)
wind1.image = windi
wind1.place(x=15, y=50) # Position image
wind2 = tkinter.Label(image=windi)
wind2.image = windi
wind2.place(x=225, y=50)
wind3 = tkinter.Label(image=windi)
wind3.image = windi
wind3.place(x=435, y=50)
windtxt = Label(root, text = 'Wind',background='white', font=("Times", 15), borderwidth=0)
windtxt.place(x=15, y=87)
windtxt1 = Label(root, text = 'Wind',background='white', font=("Times", 15))
windtxt1.place(x=225, y=87)
windtxt2 = Label(root, text = 'Wind',background='white', font=("Times", 15))
windtxt2.place(x=435, y=87)

rain = Image.open("rain2.jpg")
raini = ImageTk.PhotoImage(rain)
rain1 = tkinter.Label(image=raini,highlightthickness=0)
rain1.image = rain1
rain1.place(x=15, y=110)
rain2 = tkinter.Label(image=raini)
rain2.image = raini
rain2.place(x=225, y=110)
rain3 = tkinter.Label(image=raini)
rain3.image = raini
rain3.place(x=435, y=110)
raintxt = Label(root, text = 'Rain',background='white', font=("Times", 15))
raintxt.place(x=15, y=160)
raintxt1 = Label(root, text = 'Rain',background='white', font=("Times", 15))
raintxt1.place(x=225, y=160)
raintxt2 = Label(root, text = 'Rain',background='white', font=("Times", 15))
raintxt2.place(x=435, y=160)

temp = Image.open("temp.jpg")
tempi = ImageTk.PhotoImage(temp)
temp1 = tkinter.Label(image=tempi)
temp1.image = tempi
temp1.place(x=225, y=185)
temp2 = tkinter.Label(image=tempi)
temp2.image = tempi
temp2.place(x=15, y=185)
temp3 = tkinter.Label(image=tempi)
temp3.image = tempi
temp3.place(x=435, y=185)
temptxt = Label(root, text = 'Temperature',background='white', font=("Times", 15))
temptxt.place(x=15, y=248)
temptxt1 = Label(root, text = 'Temperature',background='white', font=("Times", 15))
temptxt1.place(x=225, y=248)
temptxt2 = Label(root, text = 'Temperature',background='white', font=("Times", 15))
temptxt2.place(x=435, y=248)

# all weather checks
ttk.Label(root, text='LAUNCH STATION', background='white', font=(my_font)).place(x=15, y=15, width=190, height=35)
ttk.Label(root, text='PATH WEATHER', background='white', font=(my_font)).place(x=225, y=15, width=180, height=35)
ttk.Label(root, text='LANDING STATION', background='white', font=(my_font)).place(x=435, y=15, width=200, height=35)


#does it check both drone and weather middle block
ttk.Label(root, text=' ', background='white').place(x=645, y=15, width=445, height=265)
ttk.Label(root, text='WEATHER', background='white', font=(my_font)).place(x=820, y=140, width=260, height=35)
ttk.Label(root, text='DRONE', background='white', font=(my_font)).place(x=835, y=15, width=210, height=35)
no = Image.open("no.jpg")
noi = ImageTk.PhotoImage(no)
no1 = tkinter.Label(image=noi)
no1.image = noi
no1.place(x=825, y=45)
yes = Image.open("greencheck.jpg")
yesi = ImageTk.PhotoImage(yes)
yes1 = tkinter.Label(image=yesi)
yes1.image = yesi
yes1.place(x=825, y=170)



#drone diagnostic block#1
ttk.Label(root, text=' ', background='white').place(x=1100, y=15, width=805, height=265)
ttk.Label(root, text='DRONE DIAGONSTICS', background='white', font=(my_font)).place(x=1390, y=15, width=300, height=35)
ustxt = Label(root, text = 'Audible',background='white', font=("Times", 15))
ustxt.place(x=1475, y=120)
us = Image.open("ultrasonic.jpg")
usi = ImageTk.PhotoImage(us)
us1 = tkinter.Label(image=usi)
us1.image = usi
us1.place(x=1475, y=45)
mtemp = Image.open("motor temp.jpg")
mtempi = ImageTk.PhotoImage(mtemp)
mtemp1 = tkinter.Label(image=mtempi)
mtemp1.image = mtempi
mtemp1.place(x=1660, y=175)
mtemptxt = Label(root, text = 'Propulsion',background='white', font=("Times", 15))
mtemptxt.place(x=1660, y=250)
rpm = Image.open("rpm.jpg")
rpmi = ImageTk.PhotoImage(rpm)
rpm1 = tkinter.Label(image=rpmi)
rpm1.image = rpmi
rpm1.place(x=1825, y=45)
rpmtxt = Label(root, text = 'RPM',background='white', font=("Times", 15))
rpmtxt.place(x=1825, y=125)
liftxt = Label(root, text = 'Lift',background='white', font=("Times", 15))
liftxt.place(x=1285, y=250)
lift = Image.open("force mount.jpg")
lifti = ImageTk.PhotoImage(lift)
lift1 = tkinter.Label(image=lifti)
lift1.image = lifti
lift1.place(x=1285, y=175)
batxt = Label(root, text = 'Battery',background='white', font=("Times", 15))
batxt.place(x=1100, y=125)
bat = Image.open("drone battery.jpg")
bati = ImageTk.PhotoImage(bat)
bat1 = tkinter.Label(image=bati)
bat1.image = bati
bat1.place(x=1100, y=45)

root.mainloop()


