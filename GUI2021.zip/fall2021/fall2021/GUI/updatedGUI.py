import tkinter
from tkinter import *
from tkinter import ttk
from tkinter.font import Font
from PIL import Image, ImageTk
import datetime

import yaml
import os
import sys
import sqlite3
import struct
import pandas as pd
import matplotlib.pyplot as plt


relative_path = '../'
with open(relative_path+'metadata.yaml', 'r') as stream:
    try:
        yaml_file = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)

db_file_path = relative_path + yaml_file['rosbag2_bagfile_information']['relative_file_paths'][0]
conn = sqlite3.connect(db_file_path)
curs = conn.cursor()
counter = 0
curs.execute("SELECT name FROM sqlite_master WHERE type = 'table';")

df = pd.read_sql_query("SELECT * FROM messages", conn)
df['first_float'] = ""
df['second_float'] = ""
for i in range(len(df['data'])):
    a,b = struct.unpack('ff',df['data'][i])
    df['first_float'][i] = a
    df['second_float'][i] = b
conn.close()

# sys.exit()
root = Tk()
root.geometry('1400x750+200+200')
# Make background and title
ttk.Label(root, text=' ', background='black').place(x=0, y=0, width=1400, height=800)
ttk.Label(root, text='Decision Making Portal', background='orange', font=("Times", 20)).place(x=15, y=10, width=260,
                                                                                              height=35)

# Make Map layout
ttk.Label(root, text='map', background='green').place(x=15, y=368, width=950, height=372)
# TODO: Take map from googlemaps API


# WeatherBlock1
# creating white box
wind_img = Image.open("wind.jpg")
rain_img = Image.open("rain2.jpg")
temp_img = Image.open("temp.jpg")
x_coords = [15, 225, 435]
stations = ['LAUNCH STATION', 'PATH WEATHER', 'LANDING STATION']

# Create weather block for every x_coord
for x_coord, station in zip(x_coords, stations):
    # Make Base for STATION
    ttk.Label(root, text=' ', background='white').place(x=x_coord, y=50, width=200, height=308)
    ttk.Label(root, text=station, background='white', font="Times 16 bold").place(x=x_coord, y=50, width=200, height=35)

    # TODO: Find wind, rain, and temp recordings for station
    wind_val = '#TODO'
    rain_val = '#TODO'
    temp_val = '#TODO'

    # Draw wind image and label
    test = ImageTk.PhotoImage(wind_img)
    tkwind_img = tkinter.Label(image=test)
    tkwind_img.image = test
    # Position image
    tkwind_img.place(x=x_coord, y=123)
    wind_text = 'Wind : '+str(wind_val)
    wind_label = Label(root, text=wind_text, background='white', font=("Times", 15), borderwidth=0)
    wind_label.place(x=x_coord, y=160)

    # Draw rain image and label
    test = ImageTk.PhotoImage(rain_img)
    tkrain_img = tkinter.Label(image=test, highlightthickness=0)
    tkrain_img.image = test
    tkrain_img.place(x=x_coord, y=190)
    rain_text = 'Chance of Rain : ' + str(rain_val)
    rain_label = Label(root, text=rain_text, background='white', font=("Times", 15))
    rain_label.place(x=x_coord, y=245)

    # Draw temperature image and label
    test = ImageTk.PhotoImage(temp_img)
    tktemp_img = tkinter.Label(image=test)
    tktemp_img.image = test
    tktemp_img.place(x=x_coord, y=270)
    temp_text = 'Temperature : '+str(temp_val)
    temp_label = Label(root, text=temp_text, background='white', font=("Times", 15))
    temp_label.place(x=x_coord, y=330)

# TODO: Check Drone and Weather and set variables accordingly
drone_check = True
weather_check = True
# Drawing Base for DRONE & WEATHER CHECK
ttk.Label(root, text=' ', background='white').place(x=645, y=50, width=320, height=308)
ttk.Label(root, text='WEATHER CHECK', background='white', font="Times 20 bold").place(x=685, y=210, width=260,
                                                                                      height=35)
ttk.Label(root, text='DRONE CHECK', background='white', font="Times 20 bold").place(x=700, y=50, width=210, height=35)

fail_img = Image.open("no.jpg")
pass_img = Image.open("greencheck.jpg")
drone_img = pass_img if drone_check else fail_img
weather_img = pass_img if weather_check else fail_img

# Place drone image based on check
test = ImageTk.PhotoImage(drone_img)
tkdrone_img = tkinter.Label(image=test)
tkdrone_img.image = test
tkdrone_img.place(x=755, y=95)

# Place weather image based on check
test = ImageTk.PhotoImage(weather_img)
tkweather_img = tkinter.Label(image=test)
tkweather_img.image = test
tkweather_img.place(x=755, y=253)

# Creating Drone Diagnostics Blocks
# Make title label
ttk.Label(root, text='DRONE DIAGNOSTICS', background='white', font="Times 20 bold").place(x=1025, y=10, width=300,
                                                                                          height=35)

# TODO: record input values to put into tkinter

audible_val = "#TODO"
propulsion_val = "#TODO"
rpm_val = "#TODO"
weight_lift_val = df['second_float'][0]
battery_val = "#TODO"

# Make Audible Label and Image using info
ttk.Label(root, text=' ', background='white').place(x=975, y=50, width=200, height=308)
audible_text = 'Audible Check: ' + str(audible_val)
audible_label = Label(root, text=audible_text, background='white', font=("Times", 15))
audible_label.place(x=975, y=125)
audible_img = Image.open("ultrasonic.jpg")
test = ImageTk.PhotoImage(audible_img)
tkaudible_img = tkinter.Label(image=test)
tkaudible_img.image = test
tkaudible_img.place(x=975, y=50)

# Make Propulsion Label and Image using info
propulsion_img = Image.open("motor temp.jpg")
test = ImageTk.PhotoImage(propulsion_img)
tkpropulsion_img = tkinter.Label(image=test)
tkpropulsion_img.image = test
tkpropulsion_img.place(x=975, y=150)
propulsion_text = 'Propulsion Check: ' + str(propulsion_val)
propulsion_label = Label(root, text=propulsion_text, background='white', font=("Times", 15))
propulsion_label.place(x=975, y=222)

# Make RPM Label and Image using info
rpm_img = Image.open("rpm.jpg")
test = ImageTk.PhotoImage(rpm_img)
tkrpm_img = tkinter.Label(image=test)
tkrpm_img.image = test
tkrpm_img.place(x=975, y=250)
rpm_text = 'RPM Check: ' + str(rpm_val)
rpm_label = Label(root, text=rpm_text, background='white', font=("Times", 15))
rpm_label.place(x=975, y=328)

# Make Second Block for diagnostics
ttk.Label(root, text=' ', background='white').place(x=1185, y=50, width=200, height=308)

# Make Weight Life Label and Image using info
weight_lift_text = 'Weight Lift Check: ' + str(weight_lift_val)
weight_lift_label = Label(root, text=weight_lift_text, background='white', font=("Times", 15))
weight_lift_label.place(x=1185, y=222)
weight_lift_img = Image.open("force mount.jpg")
test = ImageTk.PhotoImage(weight_lift_img)
tkweight_lift_img = tkinter.Label(image=test)
tkweight_lift_img.image = test
tkweight_lift_img.place(x=1185, y=150)

# Make Drone Battery Label and Image using info
battery_text = 'Drone Battery Check: ' + str(battery_val)
battery_label = Label(root, text=battery_text, background='white', font=("Times", 15))
battery_label.place(x=1185, y=125)
battery_img = Image.open("drone battery.jpg")
test = ImageTk.PhotoImage(battery_img)
tkbattery_img = tkinter.Label(image=test)
tkbattery_img.image = test
tkbattery_img.place(x=1185, y=50)

# Make ultimate Decision
decision = drone_check and weather_check

# Drawing Base for ULTIMATE DECISION
ttk.Label(root, text='', background='white').place(x=975, y=368, width=410, height=372)
ttk.Label(root, text='ULTIMATE DECISION', background='white', font="Times 20 bold").place(x=1055, y=390, width=300,
                                                                                          height=35)
if not decision:
    decision_img = Image.open("stop.jpg")
else:
    decision_img = Image.open("go.jpg")
test = ImageTk.PhotoImage(decision_img)
tkdecision_img = tkinter.Label(image=test)
tkdecision_img.image = test
tkdecision_img.place(x=1060, y=460)



time_label = Label(root,background='white',font='Times 16 bold')
time_label.pack()
time_label.config(text="NOWOW")
curr_step = 0

def clock():
    global curr_step
    curr_step = curr_step + 1
    if curr_step == 246:
        return
    time = datetime.datetime.now().strftime("Time: %H:%M:%S")
    time_label.config(text=time)

    weight_lift_val = df['second_float'][curr_step]
    weight_lift_text = 'Weight Lift Check: ' + str(weight_lift_val)
    weight_lift_label.config(text=weight_lift_text)

    new_drone_check = True if weight_lift_val < 3 else False
    new_drone_img = Image.open('greencheck.jpg') if new_drone_check else Image.open('no.jpg')
    newimg = ImageTk.PhotoImage(new_drone_img)
    tkdrone_img.configure(image=newimg)
    tkdrone_img.image = newimg

    new_decision = new_drone_check and weather_check
    if not new_decision:
        new_decision_img = Image.open("stop.jpg")
    else:
        new_decision_img = Image.open("go.jpg")
    newimg = ImageTk.PhotoImage(new_decision_img)
    tkdecision_img.configure(image=newimg)
    tkdecision_img.image = newimg

    root.after(500, clock)  # run itself again after 500 ms

clock()

root.mainloop()
