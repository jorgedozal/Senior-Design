import yaml
import os
print(os.getcwd())
with open('metadata.yaml','r') as stream:
    try:
        yaml_file = yaml.safe_load(stream)
    except yaml.YAMLError as exc:
        print(exc)
print(yaml_file.keys())
print(yaml_file['rosbag2_bagfile_information'].keys())
for key, value in yaml_file['rosbag2_bagfile_information'].items():
    print()
    print(key)
    print(value)

